#!/bin/bash
google-chrome --app="https://ais-dev-zshgfqgwkis6gglqtqvqvg-627035250074.asia-east1.run.app" 2>/dev/null || microsoft-edge --app="https://ais-dev-zshgfqgwkis6gglqtqvqvg-627035250074.asia-east1.run.app" 2>/dev/null || xdg-open "https://ais-dev-zshgfqgwkis6gglqtqvqvg-627035250074.asia-east1.run.app"
