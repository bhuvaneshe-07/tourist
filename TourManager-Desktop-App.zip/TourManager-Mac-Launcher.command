#!/bin/bash
open -a "Google Chrome" --args --app="https://ais-dev-zshgfqgwkis6gglqtqvqvg-627035250074.asia-east1.run.app" 2>/dev/null || open "https://ais-dev-zshgfqgwkis6gglqtqvqvg-627035250074.asia-east1.run.app"
