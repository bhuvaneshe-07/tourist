@echo off
title TourManager Desktop App
echo ========================================================
echo Launching TourManager Desktop Application...
echo ========================================================
start msedge --app="https://ais-dev-zshgfqgwkis6gglqtqvqvg-627035250074.asia-east1.run.app" 2>nul || start chrome --app="https://ais-dev-zshgfqgwkis6gglqtqvqvg-627035250074.asia-east1.run.app" 2>nul || start "" "https://ais-dev-zshgfqgwkis6gglqtqvqvg-627035250074.asia-east1.run.app"
exit
