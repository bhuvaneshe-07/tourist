==============================================================
TourManager Desktop Application Launcher
==============================================================

Enjoy 1-click standalone desktop access to TourManager:

ON WINDOWS (Laptops & Desktops):
1. Double-click "Launch-TourManager-Windows.bat" OR "TourManager.url".
2. TourManager opens instantly in a dedicated app window.
3. You can copy this file to your Windows Desktop for quick access anytime!

ON MAC (MacBook, iMac):
1. Double-click "Launch-TourManager-Mac.command".

ON LINUX:
1. Run "./TourManager-Linux.sh".

Direct Web App URL:
https://ais-dev-zshgfqgwkis6gglqtqvqvg-627035250074.asia-east1.run.app
